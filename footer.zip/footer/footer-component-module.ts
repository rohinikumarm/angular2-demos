import { NgModule } from '@angular/core';
import {FooterComponent} from './footer.component';
@NgModule({
  declarations: [],
  exports: [],
  imports: [],
  providers: []
})
export class FooterComponentModule {}
